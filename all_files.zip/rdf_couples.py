def rdf_couples(ndendr, cosolvent):
    """ you can add (or remove) here other possible couples for
        future analysis """
    couples = []
    if ndendr > 1:
        couples.extend([(':JAN@%f' ,':JAN@%f' ,'jan_f_jan_f'),
                 (':JAN@%o' ,':JAN@%ho','jan_ox_jan_ho'),
                 (':JAN@%oh',':JAN@%oh','jan_oh_jan_oh'),
                 (':JAN@N,N1,N2,C11,C12', ':JAN@N,N1,N2,C11,C12', 'jan_triazolo_jan_triazolo')])
    ################# COMPUTE RDF BETWEEN DENDRONS AND ETHANOL #################################
    if cosolvent=='ETN':
        couples.extend([(':JAN@%o' ,':ETN@%ho','jan_ox_etn_ho'),
                 (':JAN@%f' ,':ETN@%hc','jan_f_etn_ch3'),
                 (':JAN@%f' ,':ETN@%ho','jan_f_etn_ho'),
                 (':JAN@%nc',':ETN@%hc','jan_triazole_etn_ch3'),
                 (':JAN@%c3',':ETN@%hc','jan_csp3_etn_ch3'),
                 (':JAN@%cc',':ETN@%hc','jan_csp2triaz_etn_ch3'),
                 (':JAN@%c' ,':ETN@%hc','jan_ccarbonyl_etn_ch3'),
                 (':ETN@%hc',':ETN@%hc','etn_ch3_etn_ch3'),
                 (':JAN@%hc',':ETN@%hc','jan_hc_etn_ch3'),
                 (':JAN@%oh',':ETN@%oh','jan_oh_etn_oh')])
    ################# COMPUTE RDF BETWEEN DENDRONS AND TRIFLUOROETHANOL #################################
    if cosolvent=='TFN': 
        couples.extend([(':JAN@%o' ,':TFN@%ho','jan_ox_tfn_ho'),
                 (':JAN@%f' ,':TFN@%f' ,'jan_f_tfn_cf3'),
                 (':JAN@%f' ,':TFN@%ho','jan_f_tfn_ho'),
                 (':JAN@%nc',':TFN@%f' ,'jan_triazole_tfn_cf3'),
                 (':JAN@%c3',':TFN@%f' ,'jan_csp3_tfn_cf3'),
                 (':JAN@%cc',':TFN@%f' ,'jan_csp2triaz_tfn_cf3'),
                 (':JAN@%c' ,':TFN@%f' ,'jan_ccarbonyl_tfn_cf3'),
                 (':TFN@%f' ,':TFN@%f' ,'tfn_cf3_tfn_cf3'),
                 (':JAN@%hc',':TFN@%f' ,'jan_hc_tfn_cf3'),
                 (':JAN@%oh',':TFN@%oh','jan_oh_tfn_oh')])
    return couples
